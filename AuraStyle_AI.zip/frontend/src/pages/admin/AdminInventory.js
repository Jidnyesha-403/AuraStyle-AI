import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import AdminSidebar from "../../components/admin/AdminSidebar";
import { Input } from "@/components/ui/input";
import { Search } from "lucide-react";

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

export const AdminInventory = () => {
  const navigate = useNavigate();
  const [products, setProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const token = localStorage.getItem('adminToken');
    if (!token) {
      navigate('/admin/login');
      return;
    }
    fetchProducts();
  }, [navigate]);

  useEffect(() => {
    if (searchTerm) {
      const filtered = products.filter(p =>
        p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.category.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredProducts(filtered);
    } else {
      setFilteredProducts(products);
    }
  }, [searchTerm, products]);

  const fetchProducts = async () => {
    try {
      const response = await axios.get(`${API}/products`);
      setProducts(response.data);
      setFilteredProducts(response.data);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching products:', error);
      setLoading(false);
    }
  };

  const getStockStatus = (stock) => {
    if (stock === 0) return { label: 'Out of Stock', color: 'bg-rose-100 text-rose-700' };
    if (stock < 5) return { label: 'Low Stock', color: 'bg-amber-100 text-amber-700' };
    return { label: 'Good Stock', color: 'bg-emerald-100 text-emerald-700' };
  };

  const lowStockProducts = filteredProducts.filter(p => p.stock < 5 && p.stock > 0);
  const outOfStockProducts = filteredProducts.filter(p => p.stock === 0);

  return (
    <div className="min-h-screen bg-slate-50">
      <AdminSidebar />

      <div className="md:ml-64 p-8">
        <div className="mb-8">
          <h1 className="font-playfair text-4xl font-bold text-stone-900 mb-2" data-testid="inventory-title">My Stock</h1>
          <p className="text-stone-600">Monitor your product inventory levels</p>
        </div>

        {/* Search */}
        <div className="mb-6">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-stone-400" />
            <Input
              type="text"
              placeholder="Search products..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 h-11 bg-white"
              data-testid="inventory-search"
            />
          </div>
        </div>

        {/* Alerts */}
        {(lowStockProducts.length > 0 || outOfStockProducts.length > 0) && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
            {lowStockProducts.length > 0 && (
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-4" data-testid="low-stock-alert">
                <h3 className="font-semibold text-amber-900 mb-2">Low Stock Alert</h3>
                <p className="text-sm text-amber-700">{lowStockProducts.length} product(s) running low on stock</p>
              </div>
            )}
            {outOfStockProducts.length > 0 && (
              <div className="bg-rose-50 border border-rose-200 rounded-xl p-4" data-testid="out-of-stock-alert">
                <h3 className="font-semibold text-rose-900 mb-2">Out of Stock</h3>
                <p className="text-sm text-rose-700">{outOfStockProducts.length} product(s) out of stock</p>
              </div>
            )}
          </div>
        )}

        {loading ? (
          <div className="text-center py-12" data-testid="loading-state">
            <p className="text-stone-500">Loading inventory...</p>
          </div>
        ) : (
          <div className="bg-white rounded-xl border border-slate-100 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full" data-testid="inventory-table">
                <thead className="bg-slate-50 border-b border-slate-100">
                  <tr>
                    <th className="text-left px-6 py-4 text-sm font-semibold text-stone-700">Product</th>
                    <th className="text-left px-6 py-4 text-sm font-semibold text-stone-700">Category</th>
                    <th className="text-left px-6 py-4 text-sm font-semibold text-stone-700">Price</th>
                    <th className="text-left px-6 py-4 text-sm font-semibold text-stone-700">Current Stock</th>
                    <th className="text-left px-6 py-4 text-sm font-semibold text-stone-700">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredProducts.map(product => {
                    const stockStatus = getStockStatus(product.stock);
                    return (
                      <tr key={product.id} data-testid={`inventory-row-${product.id}`}>
                        <td className="px-6 py-4">
                          <div className="flex items-center space-x-3">
                            <img src={product.images[0]} alt={product.name} className="w-12 h-12 object-cover rounded" />
                            <div>
                              <p className="font-medium text-stone-900">{product.name}</p>
                              <p className="text-sm text-stone-500 line-clamp-1">{product.description}</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-stone-600">{product.category}</td>
                        <td className="px-6 py-4 font-semibold text-stone-900">₹{product.price.toLocaleString('en-IN')}</td>
                        <td className="px-6 py-4">
                          <span className="font-semibold text-2xl text-stone-900" data-testid={`stock-${product.id}`}>
                            {product.stock}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <span className={`px-3 py-1 rounded-full text-sm font-medium ${stockStatus.color}`} data-testid={`status-${product.id}`}>
                            {stockStatus.label}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminInventory;
